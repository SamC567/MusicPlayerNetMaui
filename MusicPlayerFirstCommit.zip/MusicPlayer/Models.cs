using System.Collections.ObjectModel;

namespace MusicPlayer.Models
{
    public class Song
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Title { get; set; } = "";
        public string Artist { get; set; } = "Unknown Artist";
        public string Album { get; set; } = "Unknown Album";
        public string FilePath { get; set; } = "";
        public string Duration { get; set; } = "00:00";
        public long DurationInMs { get; set; } = 0;
    }

    public class Playlist
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; } = "";
        public List<Song> Songs { get; set; } = new List<Song>();
        public DateTime CreatedDate { get; set; } = DateTime.Now;
    }

    public class MusicLibrary
    {
        public List<Song> Songs { get; set; } = new List<Song>();
        public List<Playlist> Playlists { get; set; } = new List<Playlist>();
    }
}