﻿using MusicPlayer.Models;
using MusicPlayer.Services;
using System.Collections.ObjectModel;

namespace MusicPlayer;

public partial class MainPage : ContentPage
{
    private readonly MusicLibraryService _libraryService;
    private readonly AudioService _audioService;
    private readonly ObservableCollection<Song> _libraryCollection;
    private readonly ObservableCollection<Song> _playlistCollection;
    private Song? _selectedLibrarySong;
    private Playlist? _currentPlaylist;
    private bool _isUpdatingProgress;

    public MainPage()
    {
        InitializeComponent();

        _libraryService = new MusicLibraryService();
        _audioService = new AudioService();
        _libraryCollection = new ObservableCollection<Song>();
        _playlistCollection = new ObservableCollection<Song>();

        MusicLibraryListView.ItemsSource = _libraryCollection;
        CurrentPlaylistListView.ItemsSource = _playlistCollection;

        // Subscribe to audio service events
        _audioService.SongChanged += OnAudioSongChanged;
        _audioService.PlayStateChanged += OnPlayStateChanged;
        _audioService.ProgressChanged += OnAudioProgressChanged;

        LoadLibrary();
        LoadPlaylists();
    }

    private void LoadLibrary()
    {
        _libraryCollection.Clear();
        var songs = _libraryService.GetAllSongs();
        foreach (var song in songs)
        {
            _libraryCollection.Add(song);
        }
    }

    private void LoadPlaylists()
    {
        var playlists = _libraryService.GetAllPlaylists();
        PlaylistPicker.ItemsSource = playlists;
        PlaylistPicker.ItemDisplayBinding = new Binding("Name");
    }

    private async void OnAddFileClicked(object sender, EventArgs e)
    {
        try
        {
            var customFileType = new FilePickerFileType(
                new Dictionary<DevicePlatform, IEnumerable<string>>
                {
                    { DevicePlatform.iOS, new[] { "public.audio" } },
                    { DevicePlatform.Android, new[] { "audio/*" } },
                    { DevicePlatform.WinUI, new[] { ".mp3", ".wav", ".m4a", ".aac", ".flac" } },
                    { DevicePlatform.macOS, new[] { "mp3", "wav", "m4a", "aac", "flac" } }
                });

            var options = new PickOptions()
            {
                PickerTitle = "Select audio files",
                FileTypes = customFileType,
            };

            var results = await FilePicker.Default.PickMultipleAsync(options);

            if (results != null)
            {
                foreach (var result in results)
                {
                    await _libraryService.AddSongAsync(result.FullPath);
                }
                LoadLibrary();
                await DisplayAlert("Success", $"Added {results.Count()} song(s) to library", "OK");
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", $"Failed to add files: {ex.Message}", "OK");
        }
    }

    private async void OnCreatePlaylistClicked(object sender, EventArgs e)
    {
        string result = await DisplayPromptAsync("Create Playlist", "Enter playlist name:", "Create", "Cancel");

        if (!string.IsNullOrWhiteSpace(result))
        {
            await _libraryService.CreatePlaylistAsync(result);
            LoadPlaylists();
            await DisplayAlert("Success", $"Created playlist '{result}'", "OK");
        }
    }

    private void OnPlaylistChanged(object sender, EventArgs e)
    {
        var picker = sender as Picker;
        if (picker?.SelectedItem is Playlist selectedPlaylist)
        {
            _currentPlaylist = selectedPlaylist;
            CurrentPlaylistLabel.Text = $"Playlist: {selectedPlaylist.Name}";

            _playlistCollection.Clear();
            foreach (var song in selectedPlaylist.Songs)
            {
                _playlistCollection.Add(song);
            }
        }
    }

    private void OnLibrarySongTapped(object sender, ItemTappedEventArgs e)
    {
        if (e.Item is Song song)
        {
            _selectedLibrarySong = song;
            AddToPlaylistButton.IsEnabled = _currentPlaylist != null;

            // Play the song immediately
            _ = Task.Run(async () =>
            {
                await _audioService.LoadSongAsync(song);
                _audioService.SetPlaylist(new List<Song> { song }, 0);
                await _audioService.PlayAsync();
            });
        }
    }

    private async void OnAddToPlaylistClicked(object sender, EventArgs e)
    {
        if (_selectedLibrarySong != null && _currentPlaylist != null)
        {
            await _libraryService.AddSongToPlaylistAsync(_currentPlaylist.Id, _selectedLibrarySong);

            // Refresh the current playlist view
            _playlistCollection.Add(_selectedLibrarySong);
            await DisplayAlert("Success", $"Added '{_selectedLibrarySong.Title}' to playlist", "OK");
        }
    }

    private async void OnPlaylistSongTapped(object sender, ItemTappedEventArgs e)
    {
        if (e.Item is Song song && _currentPlaylist != null)
        {
            var songIndex = _currentPlaylist.Songs.IndexOf(song);
            if (songIndex >= 0)
            {
                await _audioService.LoadSongAsync(song);
                _audioService.SetPlaylist(_currentPlaylist.Songs, songIndex);
                await _audioService.PlayAsync();
            }
        }
    }

    private async void OnPlayPauseClicked(object sender, EventArgs e)
    {
        if (_audioService.IsPlaying)
        {
            await _audioService.PauseAsync();
        }
        else
        {
            await _audioService.PlayAsync();
        }
    }

    private async void OnStopClicked(object sender, EventArgs e)
    {
        await _audioService.StopAsync();
    }

    private async void OnNextClicked(object sender, EventArgs e)
    {
        await _audioService.PlayNextAsync();
    }

    private async void OnPreviousClicked(object sender, EventArgs e)
    {
        await _audioService.PlayPreviousAsync();
    }

    private void OnProgressChanged(object sender, ValueChangedEventArgs e)
    {
        if (!_isUpdatingProgress && _audioService.Duration > 0)
        {
            var newPosition = (_audioService.Duration * e.NewValue) / 100.0;
            _audioService.SeekTo(newPosition);
        }
    }

    private void OnAudioSongChanged(object sender, Song song)
    {
        MainThread.BeginInvokeOnMainThread(() =>
        {
            NowPlayingLabel.Text = $"Now Playing: {song.Title} - {song.Artist}";
        });
    }

    private void OnPlayStateChanged(object sender, bool isPlaying)
    {
        MainThread.BeginInvokeOnMainThread(() =>
        {
            PlayPauseButton.Text = isPlaying ? "⏸️" : "▶️";
        });
    }

    private void OnAudioProgressChanged(object sender, double currentPosition)
    {
        MainThread.BeginInvokeOnMainThread(() =>
        {
            _isUpdatingProgress = true;

            var current = TimeSpan.FromSeconds(currentPosition);
            var total = TimeSpan.FromSeconds(_audioService.Duration);

            CurrentTimeLabel.Text = $"{current.Minutes:D2}:{current.Seconds:D2}";
            TotalTimeLabel.Text = $"{total.Minutes:D2}:{total.Seconds:D2}";

            if (total.TotalSeconds > 0)
            {
                ProgressSlider.Value = (currentPosition / total.TotalSeconds) * 100;
            }

            _isUpdatingProgress = false;
        });
    }

    protected override void OnDisappearing()
    {
        _audioService?.Dispose();
        base.OnDisappearing();
    }
}
