using System.Text.Json;
using AVFoundation;
using MusicPlayer.Models;
using Plugin.Maui.Audio;

namespace MusicPlayer.Services
{
    public class MusicLibraryService
    {
        private readonly string _dataFilePath;
        private MusicLibrary _musicLibrary;

        public MusicLibraryService()
        {
            _dataFilePath = Path.Combine(FileSystem.AppDataDirectory, "music_library.json");
            _musicLibrary = new MusicLibrary();
            LoadLibrary();
        }

        public List<Song> GetAllSongs() => _musicLibrary.Songs;
        public List<Playlist> GetAllPlaylists() => _musicLibrary.Playlists;

        public async Task AddSongAsync(string filePath)
        {
            try
            {
                var fileName = Path.GetFileNameWithoutExtension(filePath);
                var song = new Song
                {
                    Title = fileName,
                    FilePath = filePath,
                    Artist = "Unknown Artist",
                    Album = "Unknown Album"
                };

                // Try to get duration using audio service
                try
                {
                    using var audioPlayer = AudioManager.Current.CreatePlayer(filePath);
                    if (audioPlayer.Duration > 0)
                    {
                        var duration = TimeSpan.FromSeconds(audioPlayer.Duration);
                        song.Duration = $"{duration.Minutes:D2}:{duration.Seconds:D2}";
                        song.DurationInMs = (long)duration.TotalMilliseconds;
                    }
                }
                catch
                {
                    // If we can't get duration, keep default
                }

                _musicLibrary.Songs.Add(song);
                await SaveLibraryAsync();
            }
            catch (Exception ex)
            {
                throw new Exception($"Error adding song: {ex.Message}");
            }
        }

        public async Task CreatePlaylistAsync(string name)
        {
            var playlist = new Playlist { Name = name };
            _musicLibrary.Playlists.Add(playlist);
            await SaveLibraryAsync();
        }

        public async Task AddSongToPlaylistAsync(string playlistId, Song song)
        {
            var playlist = _musicLibrary.Playlists.FirstOrDefault(p => p.Id == playlistId);
            if (playlist != null && !playlist.Songs.Any(s => s.Id == song.Id))
            {
                playlist.Songs.Add(song);
                await SaveLibraryAsync();
            }
        }

        public async Task RemoveSongFromPlaylistAsync(string playlistId, string songId)
        {
            var playlist = _musicLibrary.Playlists.FirstOrDefault(p => p.Id == playlistId);
            if (playlist != null)
            {
                var song = playlist.Songs.FirstOrDefault(s => s.Id == songId);
                if (song != null)
                {
                    playlist.Songs.Remove(song);
                    await SaveLibraryAsync();
                }
            }
        }

        public Playlist? GetPlaylist(string playlistId)
        {
            return _musicLibrary.Playlists.FirstOrDefault(p => p.Id == playlistId);
        }

        private async Task SaveLibraryAsync()
        {
            try
            {
                var json = JsonSerializer.Serialize(_musicLibrary, new JsonSerializerOptions
                {
                    WriteIndented = true
                });
                await File.WriteAllTextAsync(_dataFilePath, json);
            }
            catch (Exception ex)
            {
                // Log error or handle as needed
                throw new Exception($"Error saving library: {ex.Message}");
            }
        }

        private void LoadLibrary()
        {
            try
            {
                if (File.Exists(_dataFilePath))
                {
                    var json = File.ReadAllText(_dataFilePath);
                    var library = JsonSerializer.Deserialize<MusicLibrary>(json);
                    if (library != null)
                    {
                        _musicLibrary = library;
                    }
                }
            }
            catch
            {
                // If loading fails, start with empty library
                _musicLibrary = new MusicLibrary();
            }
        }
    }

    public class AudioService
    {
        private IAudioPlayer? _currentPlayer;
        private Song? _currentSong;
        private List<Song> _currentPlaylist;
        private int _currentIndex;
        private bool _isPlaying;
        private Timer? _progressTimer;

        public event EventHandler<Song>? SongChanged;
        public event EventHandler<bool>? PlayStateChanged;
        public event EventHandler<double>? ProgressChanged;

        public AudioService()
        {
            _currentPlaylist = new List<Song>();
            _currentIndex = -1;
        }

        public Song? CurrentSong => _currentSong;
        public bool IsPlaying => _isPlaying;
        public double Duration => _currentPlayer?.Duration ?? 0;
        public double CurrentPosition => _currentPlayer?.CurrentPosition ?? 0;

        public async Task LoadSongAsync(Song song)
        {
            try
            {
                await StopAsync();

                if (File.Exists(song.FilePath))
                {
                    _currentPlayer = AudioManager.Current.CreatePlayer(song.FilePath);
                    _currentSong = song;
                    SongChanged?.Invoke(this, song);
                }
                else
                {
                    throw new FileNotFoundException($"Audio file not found: {song.FilePath}");
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error loading song: {ex.Message}");
            }
        }

        public async Task PlayAsync()
        {
            if (_currentPlayer != null && !_isPlaying)
            {
                _currentPlayer.Play();
                _isPlaying = true;
                PlayStateChanged?.Invoke(this, true);
                StartProgressTimer();
            }
        }

        public async Task PauseAsync()
        {
            if (_currentPlayer != null && _isPlaying)
            {
                _currentPlayer.Pause();
                _isPlaying = false;
                PlayStateChanged?.Invoke(this, false);
                StopProgressTimer();
            }
        }

        public async Task StopAsync()
        {
            if (_currentPlayer != null)
            {
                _currentPlayer.Stop();
                _isPlaying = false;
                PlayStateChanged?.Invoke(this, false);
                StopProgressTimer();
            }
        }

        public void SetPlaylist(List<Song> playlist, int startIndex = 0)
        {
            _currentPlaylist = playlist;
            _currentIndex = startIndex;
        }

        public async Task PlayNextAsync()
        {
            if (_currentPlaylist.Count > 0 && _currentIndex < _currentPlaylist.Count - 1)
            {
                _currentIndex++;
                await LoadSongAsync(_currentPlaylist[_currentIndex]);
                await PlayAsync();
            }
        }

        public async Task PlayPreviousAsync()
        {
            if (_currentPlaylist.Count > 0 && _currentIndex > 0)
            {
                _currentIndex--;
                await LoadSongAsync(_currentPlaylist[_currentIndex]);
                await PlayAsync();
            }
        }

        public void SeekTo(double position)
        {
            if (_currentPlayer != null)
            {
                _currentPlayer.Seek(position);
            }
        }

        private void StartProgressTimer()
        {
            StopProgressTimer();
            _progressTimer = new Timer(UpdateProgress, null, TimeSpan.Zero, TimeSpan.FromMilliseconds(500));
        }

        private void StopProgressTimer()
        {
            _progressTimer?.Dispose();
            _progressTimer = null;
        }

        private void UpdateProgress(object? state)
        {
            if (_currentPlayer != null && _isPlaying)
            {
                var progress = _currentPlayer.CurrentPosition;
                ProgressChanged?.Invoke(this, progress);

                // Auto-advance to next song when current song ends
                if (progress >= _currentPlayer.Duration - 0.5) // Small buffer for end detection
                {
                    MainThread.BeginInvokeOnMainThread(async () =>
                    {
                        await PlayNextAsync();
                    });
                }
            }
        }

        public void Dispose()
        {
            StopProgressTimer();
            _currentPlayer?.Dispose();
        }
    }
}